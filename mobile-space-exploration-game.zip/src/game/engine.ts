// Mesin permainan: fisika kapal, EVA, kamera, tata surya, progres, HUD
import * as THREE from 'three';
import { Body } from './body';
import { makeSolarSystem, generateWorld, type BodyDef } from './bodies';
import { buildShip, type ShipRig, GEAR_H, PILOT_EYE, WALK_START, HATCH_OUT, AIRLOCK_IN, SEAT_POS } from './shipModel';
import { GameAudio } from './audio';
import { drawRadar, drawNav, drawStatus, drawMap, type ScreenData, type Blip } from './screens';
import { makeStarfield, makeStation, makeVoyager, makeFlag, AsteroidBelt, Dust, makeFlares } from './extras';
import { clamp, smooth } from './noise';

export type Mode = 'pilot' | 'walk' | 'eva' | 'airlock';

export interface Hud {
  mode: Mode;
  view: 'cockpit' | 'chase';
  look: boolean;
  speed: number;
  alt: number;
  nearest: string;
  throttle: number;
  limit: number;
  landed: boolean;
  grounded: boolean;
  target: { id: string; name: string; dist: number } | null;
  marker: { x: number; y: number; behind: boolean } | null;
  autopilot: boolean;
  prompt: { text: string; action: string } | null;
  oxygen: number;
  heat: number;
  glare: number;
  atmo: number;
  gasDepth: number;
  warn: string | null;
  seq: string | null;
  fade: number;
  nearSurface: boolean;
  counts: { disc: number; visit: number; landed: number; flags: number; total: number };
  gravity: number;
  boost: boolean;
  muted: boolean;
}

export interface TargetInfo {
  id: string;
  name: string;
  kind: string;
  dist: number;
  radius: number;
  discovered: boolean;
  visited: boolean;
  landed: boolean;
  flagged: boolean;
  info?: BodyDef['info'];
  gen: boolean;
  parent: string | null;
}

export interface Events {
  onHud: (h: Hud) => void;
  onToast: (msg: string, kind: 'info' | 'discover' | 'warn') => void;
  onProgress: (p: number, label: string) => void;
}

interface Target {
  id: string;
  name: string;
  kind: string;
  pos: THREE.Vector3;
  radius: number;
  body?: Body;
  info?: BodyDef['info'];
}

const VMAX = 300000;
const tick = () => new Promise<void>((r) => setTimeout(r, 0));
const X = new THREE.Vector3(1, 0, 0), Y = new THREE.Vector3(0, 1, 0), Z = new THREE.Vector3(0, 0, 1);

export class Engine {
  container: HTMLElement;
  ev: Events;
  renderer!: THREE.WebGLRenderer;
  camera!: THREE.PerspectiveCamera;
  world = new THREE.Scene();
  shipScene = new THREE.Scene();
  audio = new GameAudio();
  rig!: ShipRig;
  bodies: Body[] = [];
  byId = new Map<string, Body>();
  landmarks: Target[] = [];
  station!: THREE.Group;
  voyager!: THREE.Group;
  belt!: AsteroidBelt;
  dust!: Dust;
  flares: ReturnType<typeof makeFlares> = [];
  stars!: ReturnType<typeof makeStarfield>;
  sunLight = new THREE.PointLight(0xfff2e0, 3.6, 0, 0);
  ambient = new THREE.AmbientLight(0x7a88aa, 0.2);
  sun!: Body;

  // status
  mode: Mode = 'pilot';
  view: 'cockpit' | 'chase' = 'cockpit';
  lookMode = false;
  time = 0;
  raf = 0;
  last = 0;
  frameN = 0;
  buildBudget = 4;
  running = false;

  shipPos = new THREE.Vector3();
  shipVel = new THREE.Vector3();
  shipQuat = new THREE.Quaternion();
  origin = new THREE.Vector3();
  throttle = 0;
  braking = false;
  autopilot = false;
  boost = false;
  landed = false;
  contact = false;
  landTimer = 0;
  targetId: string | null = null;

  headYaw = 0;
  headPitch = 0;
  walkPos = WALK_START.clone();
  eyeLocal = PILOT_EYE.clone();
  walkYaw = 0;

  astro = { pos: new THREE.Vector3(), vel: new THREE.Vector3(), quat: new THREE.Quaternion(), grounded: false, gfac: 0, g: 0 };
  oxygen = 1;
  autoReturn = false;
  seq: { type: 'exit' | 'enter'; t: number; label: string; done1: boolean; done2: boolean; done3: boolean } | null = null;
  fade = 0;
  hull = 1;
  energy = 1;

  input = { steerX: 0, steerY: 0, roll: 0, moveX: 0, moveY: 0, vert: 0, jetUp: false, jetDown: false, jump: false, lookDX: 0, lookDY: 0, run: false };
  keys = new Set<string>();

  env = { nearest: null as Body | null, alt: 1e9, limit: VMAX, dens: 0, atmBody: null as Body | null, gasDepth: 0, rockAlt: 1e9 };
  envCam = { nearest: null as Body | null, alt: 1e9, limit: VMAX, dens: 0, atmBody: null as Body | null, gasDepth: 0, rockAlt: 1e9 };
  heat = 0;
  glare = 0;
  warn: string | null = null;
  warnT = 0;
  genCount = 0;
  hudT = 0;
  scrT = 0;
  flags: { body: Body; mesh: THREE.Object3D }[] = [];
  beltToast = false;
  lastDiscCheck = 0;
  prevSpeed = 0;
  shake = 0;

  // temp
  private q1 = new THREE.Quaternion();
  private q2 = new THREE.Quaternion();
  private q3 = new THREE.Quaternion();
  private v1 = new THREE.Vector3();
  private v2 = new THREE.Vector3();
  private v3 = new THREE.Vector3();
  private v4 = new THREE.Vector3();
  private m4 = new THREE.Matrix4();
  private camQ = new THREE.Quaternion();
  private camP = new THREE.Vector3();

  constructor(container: HTMLElement, ev: Events) {
    this.container = container;
    this.ev = ev;
  }

  // =============================================================== INIT
  async init() {
    const p = (v: number, l: string) => this.ev.onProgress(v, l);
    p(0.02, 'Menyalakan mesin grafis');
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    this.renderer = new THREE.WebGLRenderer({ antialias: dpr < 1.5, powerPreference: 'high-performance', logarithmicDepthBuffer: true });
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.autoClear = false;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.domElement.style.touchAction = 'none';
    this.renderer.domElement.style.display = 'block';
    this.container.appendChild(this.renderer.domElement);
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.05, 4e9);
    this.world.add(this.sunLight, this.ambient);
    this.onResize();
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKey);
    await tick();

    p(0.05, 'Menyusun galaksi');
    this.stars = makeStarfield();
    this.world.add(this.stars.group);
    this.flares = makeFlares(this.world);
    this.dust = new Dust(this.world);
    this.belt = new AsteroidBelt(this.world);
    await tick();

    const defs = makeSolarSystem();
    for (let i = 0; i < defs.length; i++) {
      p(0.1 + (i / defs.length) * 0.55, `Membangkitkan ${defs[i].name}`);
      const b = new Body(defs[i], this.world);
      this.bodies.push(b);
      this.byId.set(b.id, b);
      await tick();
    }
    this.sun = this.byId.get('matahari')!;

    p(0.7, 'Membangun stasiun & wahana');
    this.station = makeStation();
    this.world.add(this.station);
    this.voyager = makeVoyager();
    this.world.add(this.voyager);
    this.landmarks.push(
      { id: 'stasiun', name: 'Stasiun Garuda', kind: 'Stasiun Antariksa', pos: new THREE.Vector3(), radius: 700, info: { radiusKm: '~1,2 km', gravity: 'Gaya sentrifugal', temp: '21 °C', atm: 'Terkendali', desc: 'Stasiun antariksa berputar yang mengorbit Bumi. Cincin hunian, panel surya, dan lampu navigasinya berkedip di kegelapan.' } },
      { id: 'voyager', name: 'Voyager 1', kind: 'Wahana Antariksa', pos: new THREE.Vector3(70e6, 5e6, -22e6), radius: 20, info: { radiusKm: '~3,7 m', gravity: '—', temp: '-250 °C', atm: 'Hampa', desc: 'Wahana tertua yang menjelajah di luar tata surya, membawa piringan emas "Golden Record" berisi suara Bumi.' } }
    );
    await tick();

    p(0.76, 'Merakit kapal Nusantara-7');
    this.rig = buildShip();
    this.shipScene.add(this.rig.group, this.rig.sun);
    await tick();

    // posisi awal: dekat Bumi sisi siang
    for (const b of this.bodies) { b.orbit(this.time, this.byId); b.orbit(this.time, this.byId); }
    this.updateLandmarks();
    const bumi = this.byId.get('bumi')!;
    const toSun = this.v1.copy(this.sun.pos).sub(bumi.pos).normalize();
    toSun.applyAxisAngle(Y, 0.7);
    toSun.y += 0.28;
    toSun.normalize();
    this.shipPos.copy(bumi.pos).addScaledVector(toSun, bumi.R * 3.6);
    this.m4.lookAt(new THREE.Vector3(0, 0, 0), this.v3.copy(bumi.pos).sub(this.shipPos).normalize(), Y);
    this.shipQuat.setFromRotationMatrix(this.m4);
    this.origin.copy(this.shipPos);

    // pemanasan LOD
    this.buildBudget = 60;
    for (let i = 0; i < 22; i++) {
      p(0.8 + (i / 22) * 0.19, 'Membentuk permukaan planet');
      this.step(0.001);
      this.render();
      await tick();
    }
    this.buildBudget = 4;
    p(1, 'Siap');
  }

  start() {
    this.running = true;
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKey);
    this.audio.dispose();
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
  }

  onResize = () => {
    if (!this.renderer) return;
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h);
    const asp = w / h;
    this.camera.aspect = asp;
    this.baseFov = asp < 1 ? clamp((2 * Math.atan(Math.tan((72 * Math.PI) / 360) / asp) * 180) / Math.PI, 72, 104) : 72;
    this.camera.fov = this.baseFov;
    this.camera.updateProjectionMatrix();
  };
  baseFov = 72;

  onKey = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
    const k = e.key.toLowerCase();
    if (e.type === 'keydown') {
      if (e.repeat) return;
      this.keys.add(k);
      if (k === 'f') this.interact();
      if (k === ' ') this.input.jump = true;
      if (k === 't') this.standSit();
      if (k === 'g') this.plantFlag();
      if (k === 'x') this.brake(true);
      if (k === 'v') this.toggleView();
      if (k === 'b') this.setBoost(true);
      if (k === 'm') this.audio.setMuted(!this.audio.muted);
    } else {
      this.keys.delete(k);
      if (k === 'x') this.brake(false);
      if (k === 'b') this.setBoost(false);
    }
  };

  // =============================================================== PUBLIC ACTIONS
  startAudio() { this.audio.start(); }
  setThrottle(v: number) {
    this.throttle = clamp(v);
    if (this.autopilot) { this.autopilot = false; this.toast('Autopilot dimatikan (kendali manual)', 'info'); }
    if (v > 0.02) this.braking = false;
  }
  setSteer(x: number, y: number) { this.input.steerX = x; this.input.steerY = y; }
  setMove(x: number, y: number, run = false) { this.input.moveX = x; this.input.moveY = y; this.input.run = run; }
  setRoll(r: number) { this.input.roll = r; }
  setVert(v: number) { this.input.vert = v; }
  setJet(up: boolean, down: boolean) { this.input.jetUp = up; this.input.jetDown = down; }
  addLook(dx: number, dy: number) { this.input.lookDX += dx; this.input.lookDY += dy; }
  brake(b: boolean) {
    this.braking = b;
    if (b) { this.autopilot = false; this.throttle = 0; }
  }
  setBoost(b: boolean) {
    if (b && !this.boost && this.mode === 'pilot') this.audio.boost();
    this.boost = b;
  }
  toggleLook() { this.lookMode = !this.lookMode; this.audio.click(); }
  toggleView() {
    if (this.mode !== 'pilot') return;
    this.view = this.view === 'cockpit' ? 'chase' : 'cockpit';
    this.headYaw = 0; this.headPitch = this.view === 'chase' ? 0.15 : 0;
    this.audio.click();
  }
  toggleMute() { this.audio.setMuted(!this.audio.muted); }
  jump() { this.input.jump = true; }

  selectTarget(id: string | null) {
    this.targetId = id;
    this.audio.select();
  }

  engageAutopilot() {
    const t = this.getTarget();
    if (!t) { this.toast('Pilih target di peta terlebih dahulu', 'warn'); return; }
    if (this.mode === 'eva') return;
    this.autopilot = true;
    this.braking = false;
    this.view = this.view;
    this.audio.engage();
    this.toast(`Autopilot menuju ${t.name}`, 'info');
  }
  cancelAutopilot() { if (this.autopilot) { this.autopilot = false; this.audio.close(); this.toast('Autopilot dimatikan', 'info'); } }

  scanTarget() {
    const t = this.getTarget();
    if (!t) { this.toast('Pilih target untuk dipindai', 'warn'); return; }
    this.audio.scan();
    setTimeout(() => this.toast(`Pemindaian ${t.name} selesai`, 'info'), 1100);
  }

  standSit() {
    if (this.mode === 'pilot') {
      if (this.view === 'chase') { this.view = 'cockpit'; }
      this.mode = 'walk';
      this.walkPos.set(-0.45, 1.65, -1.9);
      this.walkYaw = 0;
      this.headYaw = 0; this.headPitch = 0;
      this.autopilotKeep();
      this.audio.open();
    } else if (this.mode === 'walk') {
      const dx = this.walkPos.x - SEAT_POS.x, dz = this.walkPos.z - SEAT_POS.z;
      if (Math.hypot(dx, dz) < 1.7) {
        this.mode = 'pilot';
        this.headYaw = 0; this.headPitch = 0;
        this.audio.close();
      } else this.toast('Dekati kursi pilot untuk duduk', 'info');
    }
  }
  private autopilotKeep() { /* autopilot tetap berjalan saat berjalan di kabin */ }

  interact() {
    const pr = this.getPrompt();
    if (!pr) return;
    if (pr.action === 'sit') this.standSit();
    else if (pr.action === 'exit') this.startExit();
    else if (pr.action === 'enter') this.startEnter();
    else if (pr.action === 'flag') this.plantFlag();
    else if (pr.action === 'stand') this.standSit();
  }

  returnToShip() {
    if (this.mode !== 'eva') return;
    this.autoReturn = true;
    this.toast('Tali penarik diaktifkan — kembali ke kapal', 'info');
    this.audio.engage();
  }

  startExit() {
    if (this.mode !== 'walk' || this.seq) return;
    const sp = this.shipVel.length();
    if (sp > 40) { this.toast('Kapal harus hampir diam (<40 m/s) — tekan REM', 'warn'); this.audio.warn(); return; }
    if (this.env.nearest && (this.env.nearest.isSun || (this.env.nearest.isGas && this.env.alt < this.env.nearest.R * 0.2)) && this.env.alt < this.env.nearest.R * 1.5) {
      this.toast('Terlalu berbahaya untuk keluar di sini', 'warn');
      this.audio.warn();
      return;
    }
    this.autopilot = false;
    this.throttle = 0;
    this.mode = 'airlock';
    this.seq = { type: 'exit', t: 0, label: 'Menyegel airlock…', done1: false, done2: false, done3: false };
    this.audio.thunk();
  }

  startEnter() {
    if (this.mode !== 'eva' || this.seq) return;
    this.autoReturn = false;
    this.seq = { type: 'enter', t: 0, label: 'Masuk airlock…', done1: false, done2: false, done3: false };
    this.audio.thunk();
  }

  plantFlag() {
    if (this.mode !== 'eva') return;
    const b = this.envCam.nearest;
    if (!b || !b.isTerrain || !this.astro.grounded) { this.toast('Berdirilah di permukaan padat untuk menancapkan bendera', 'warn'); return; }
    const rel = this.v1.copy(this.astro.pos).sub(b.pos);
    const dirW = rel.clone().normalize();
    const dirL = b.toLocal(dirW, new THREE.Vector3());
    const r = b.surfaceRadius(dirL);
    const flag = makeFlag();
    flag.position.copy(dirL).multiplyScalar(r);
    this.q1.setFromUnitVectors(Y, dirL);
    flag.quaternion.copy(this.q1);
    // posisi sedikit di depan pemain
    b.spinG.add(flag);
    this.flags.push({ body: b, mesh: flag });
    if (!b.flagged) {
      b.flagged = true;
      this.toast(`Bendera Merah Putih berkibar di ${b.def.name}!`, 'discover');
      this.audio.discover();
    }
    this.audio.flag();
  }

  spawnWorld() {
    if (this.genCount >= 4) { this.toast('Batas dunia generatif tercapai', 'warn'); return; }
    this.genCount++;
    const f = this.v1.set(0, 0, -1).applyQuaternion(this.shipQuat);
    const pos: [number, number, number] = [this.shipPos.x + f.x * 4.5e6, this.shipPos.y + f.y * 4.5e6 + 2e5, this.shipPos.z + f.z * 4.5e6];
    const def = generateWorld(Math.floor(Math.random() * 1e9), this.genCount, pos);
    const b = new Body(def, this.world);
    b.orbit(this.time, this.byId); b.orbit(this.time, this.byId);
    this.bodies.push(b);
    this.byId.set(b.id, b);
    this.targetId = b.id;
    this.audio.discover();
    this.toast(`Dunia baru dibangkitkan: ${def.name} — di depan kapal`, 'discover');
  }

  toast(msg: string, kind: 'info' | 'discover' | 'warn' = 'info') { this.ev.onToast(msg, kind); }

  // =============================================================== TARGET
  allTargets(): Target[] {
    const arr: Target[] = this.bodies.map((b) => ({ id: b.id, name: b.def.name, kind: b.def.kind, pos: b.pos, radius: b.R, body: b, info: b.def.info }));
    return arr.concat(this.landmarks);
  }
  getTarget(): Target | null {
    if (!this.targetId) return null;
    return this.allTargets().find((t) => t.id === this.targetId) || null;
  }
  listTargets(): TargetInfo[] {
    const o = this.mode === 'eva' ? this.astro.pos : this.shipPos;
    return this.allTargets().map((t) => ({
      id: t.id, name: t.name, kind: t.kind, dist: Math.max(0, t.pos.distanceTo(o) - t.radius), radius: t.radius,
      discovered: t.body ? t.body.discovered : true, visited: t.body ? t.body.visited : false,
      landed: t.body ? t.body.landedOn : false, flagged: t.body ? t.body.flagged : false,
      info: t.info, gen: !!t.body?.def.fixedPos, parent: t.body ? t.body.def.parent : null,
    }));
  }

  private updateLandmarks() {
    const bumi = this.byId.get('bumi')!;
    const a = 0.5 + (150 / 180000) * this.time;
    const st = this.landmarks[0];
    st.pos.set(bumi.pos.x + Math.cos(a) * 190000, bumi.pos.y + Math.sin(a * 0.7) * 25000, bumi.pos.z + Math.sin(a) * 190000);
    this.landmarks[0].pos = st.pos;
  }

  // =============================================================== LOOP
  loop = (now: number) => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min((now - this.last) / 1000, 0.05);
    this.last = now;
    if (dt <= 0) return;
    this.step(dt);
    this.render();
  };

  private applyFrame(pos: THREE.Vector3, quat: THREE.Quaternion | null) {
    let best: Body | null = null, br = 1e9;
    for (const b of this.bodies) {
      const d = pos.distanceTo(b.pos) / b.R;
      if (d < br) { br = d; best = b; }
    }
    if (best && br < 6) {
      pos.add(this.v4.copy(best.pos).sub(best.prevPos));
      if (br < 1.35 && !best.isSun) {
        this.q3.copy(best.prevQuat).invert();
        this.q3.premultiply(best.quat);
        const rel = this.v4.copy(pos).sub(best.pos).applyQuaternion(this.q3);
        pos.copy(best.pos).add(rel);
        if (quat) quat.premultiply(this.q3);
      }
    }
  }

  // lingkungan (jarak permukaan, batas kecepatan, atmosfer)
  private computeEnv(pos: THREE.Vector3, e: Engine['env']) {
    let near: Body | null = null, nr = 1e9, lim = VMAX * (this.boost ? 2 : 1), dens = 0, atmB: Body | null = null, nearAlt = 1e9, gasDepth = 0;
    const kf = this.boost ? 1.4 : 0.5;
    for (const b of this.bodies) {
      const rel = this.v1.copy(pos).sub(b.pos);
      const d = rel.length();
      let alt = d - b.R;
      if (b.isTerrain && d < b.R + b.def.t!.amp * 3 + 800) {
        const dl = b.toLocal(rel.multiplyScalar(1 / d), this.v2);
        alt = d - b.surfaceRadius(dl);
      }
      const ratio = alt / b.R;
      if (ratio < nr) { nr = ratio; near = b; nearAlt = alt; }
      if (b.isGas && alt < 0) lim = Math.min(lim, 400);
      else lim = Math.min(lim, Math.max(alt, 0) * kf + 6);
      if (b.def.atm) {
        let dn = 0;
        if (alt < b.atmThickness * 1.3) {
          dn = Math.exp(-Math.max(alt, 0) / b.def.atm.h);
          if (b.isGas && alt < 0) { dn = 1 + Math.min(-alt / (b.R * 0.05), 0.8); gasDepth = Math.max(gasDepth, -alt / b.R); }
        }
        if (dn > dens) { dens = dn; atmB = b; }
      }
    }
    if (this.belt.inside) {
      for (const r of this.belt.rocks) {
        const d = Math.hypot(pos.x - r.x, pos.y - r.y, pos.z - r.z) - r.r;
        if (d < 40000) lim = Math.min(lim, Math.max(d, 0) * kf + 6);
      }
    }
    e.nearest = near; e.alt = nearAlt; e.limit = Math.max(6, lim); e.dens = dens; e.atmBody = atmB; e.gasDepth = gasDepth;
  }

  private rollLevel(q: THREE.Quaternion, up: THREE.Vector3, k: number) {
    const f = this.v2.set(0, 0, -1).applyQuaternion(q);
    const r = this.v3.set(1, 0, 0).applyQuaternion(q);
    const rd = this.v4.copy(f).cross(up);
    if (rd.lengthSq() < 1e-4) return;
    rd.normalize();
    const cr = this.v1.copy(r).cross(rd);
    const ang = Math.atan2(f.dot(cr), r.dot(rd));
    this.q3.setFromAxisAngle(f, ang * k);
    q.premultiply(this.q3);
  }

  step(dt: number) {
    this.time += dt;
    this.frameN++;
    // orbit
    for (const b of this.bodies) b.orbit(this.time, this.byId);
    this.updateLandmarks();
    this.applyFrame(this.shipPos, this.shipQuat);
    if (this.mode === 'eva') this.applyFrame(this.astro.pos, this.astro.quat);

    this.computeEnv(this.shipPos, this.env);
    this.keyboardInput(dt);

    if (this.mode === 'eva') this.stepAstro(dt);
    else this.stepShip(dt);

    this.stepSequence(dt);
    this.stepWalk(dt);

    // oksigen
    if (this.mode === 'eva') {
      this.oxygen = Math.max(0, this.oxygen - dt / 420);
      if (this.oxygen < 0.2 && Math.floor(this.time * 2) % 8 === 0 && !this.warn) this.setWarn('Oksigen rendah', 3);
      if (this.oxygen <= 0 && !this.autoReturn) { this.autoReturn = true; this.toast('Oksigen habis! Penarikan darurat ke kapal', 'warn'); this.audio.warn(); }
    } else this.oxygen = Math.min(1, this.oxygen + dt * 0.15);

    this.cameraUpdate(dt);
    this.worldUpdate(dt);
    this.progressCheck(dt);

    // HUD & layar
    this.hudT += dt; this.scrT += dt;
    if (this.scrT > 0.12) { this.scrT = 0; this.drawScreens(); }
    if (this.hudT > 0.1) { this.hudT = 0; this.ev.onHud(this.makeHud()); }
    if (this.warnT > 0) { this.warnT -= dt; if (this.warnT <= 0) this.warn = null; }
    this.input.lookDX = 0; this.input.lookDY = 0;
    this.input.jump = false;

    // audio
    const speed = this.mode === 'eva' ? this.astro.vel.length() : this.shipVel.length();
    this.audio.update({
      throttle: this.mode === 'eva' ? 0 : Math.max(this.throttle, clamp(this.shipVel.length() / Math.max(1, this.env.limit))) * 0.9,
      speed01: clamp(Math.log10(1 + this.shipVel.length()) / 5.5),
      atmo: clamp(this.envCam.dens), inside: this.mode !== 'eva', eva: this.mode === 'eva',
      jet: this.mode === 'eva' && (this.input.jetUp || this.input.jetDown || this.input.moveY !== 0 && !this.astro.grounded) ? 1 : 0,
      walking: (this.mode === 'walk' && (Math.abs(this.input.moveX) + Math.abs(this.input.moveY) > 0.2)) || (this.mode === 'eva' && this.astro.grounded && (Math.abs(this.input.moveX) + Math.abs(this.input.moveY) > 0.2)),
      heat: this.heat, windSpeed: clamp(speed / 1500),
    }, dt);
    this.prevSpeed = speed;
  }

  private setWarn(m: string, t = 2.5) { this.warn = m; this.warnT = t; }

  private keyboardInput(dt: number) {
    const k = this.keys;
    if (!k.size) {
      if (this.kbWas) {
        this.kbWas = false;
        const i = this.input;
        i.steerX = 0; i.steerY = 0; i.roll = 0; i.moveX = 0; i.moveY = 0; i.vert = 0; i.jetUp = false; i.jetDown = false; i.run = false;
      }
      return;
    }
    this.kbWas = true;
    const has = (s: string) => k.has(s);
    const ax = (has('d') || has('arrowright') ? 1 : 0) - (has('a') || has('arrowleft') ? 1 : 0);
    const ay = (has('w') || has('arrowup') ? 1 : 0) - (has('s') || has('arrowdown') ? 1 : 0);
    if (this.mode === 'pilot') {
      this.input.steerX = ax * 0.8; this.input.steerY = ay * 0.8;
      this.input.roll = (has('e') ? 1 : 0) - (has('q') ? 1 : 0);
      if (has('shift')) this.throttle = clamp(this.throttle + dt * 0.5);
      if (has('control')) this.throttle = clamp(this.throttle - dt * 0.5);
      this.input.vert = (has(' ') ? 1 : 0) - (has('c') ? 1 : 0);
    } else {
      this.input.moveX = ax; this.input.moveY = ay;
      this.input.run = has('shift');
      this.input.jetUp = has(' ');
      this.input.jetDown = has('c');
    }
  }
  kbWas = false;

  // ------------------------------------------------ kapal
  private stepShip(dt: number) {
    const Q = this.shipQuat;
    const env = this.env;
    const lim = env.limit;
    const inp = this.input;
    const nb = env.nearest;
    const f = this.v2.set(0, 0, -1).applyQuaternion(Q).clone();
    const upS = new THREE.Vector3(0, 1, 0).applyQuaternion(Q);
    const radial = nb ? this.v3.copy(this.shipPos).sub(nb.pos).normalize().clone() : upS.clone();

    // autopilot
    const tgt = this.getTarget();
    let userOverride = false;
    if (this.mode === 'pilot' && !this.lookMode && (Math.abs(inp.steerX) > 0.6 || Math.abs(inp.steerY) > 0.6)) userOverride = true;
    if (this.autopilot && tgt && !userOverride) {
      const to = this.v1.copy(tgt.pos).sub(this.shipPos);
      const dist = to.length();
      const dir = to.clone().normalize();
      this.m4.lookAt(new THREE.Vector3(0, 0, 0), dir, upS);
      this.q1.setFromRotationMatrix(this.m4);
      const angle = Q.angleTo(this.q1);
      Q.rotateTowards(this.q1, 1.3 * dt);
      const stopAlt = clamp(tgt.radius * 0.7, 6000, 80000) + (tgt.body && tgt.body.def.atm ? tgt.body.def.atm.h * 2 : 0);
      const altT = dist - tgt.radius;
      if (altT < stopAlt) {
        this.autopilot = false;
        this.throttle = 0;
        this.toast(`Tiba di ${tgt.name} — kendali manual`, 'discover');
        this.audio.discover();
      } else this.throttle = angle > 0.5 ? 0.0 : angle > 0.12 ? 0.25 : 1;
    } else if (this.autopilot && userOverride) {
      this.autopilot = false;
      this.toast('Autopilot dimatikan (kendali manual)', 'info');
    } else if (this.mode === 'pilot' && !this.lookMode) {
      const cv = (v: number) => Math.sign(v) * Math.pow(Math.abs(v), 1.5);
      const landedLock = this.contact && this.landed;
      const rate = 0.95;
      const sx = cv(inp.steerX), sy = landedLock ? 0 : cv(inp.steerY), rl = landedLock ? 0 : inp.roll;
      this.q1.setFromAxisAngle(Y, -sx * rate * dt);
      this.q2.setFromAxisAngle(X, sy * rate * dt);
      this.q3.setFromAxisAngle(Z, -rl * 1.0 * dt);
      Q.multiply(this.q1).multiply(this.q2).multiply(this.q3);
    } else if (this.mode === 'pilot') {
      // mode lihat: roll masih bisa
      if (inp.roll) { this.q3.setFromAxisAngle(Z, -inp.roll * dt); Q.multiply(this.q3); }
    }
    Q.normalize();

    // auto-level
    if (nb && !nb.isSun) {
      const altN = env.alt;
      if (this.landed && this.contact) {
        const cu = new THREE.Vector3(0, 1, 0).applyQuaternion(Q);
        this.q1.setFromUnitVectors(cu, radial);
        this.q2.identity().slerp(this.q1, 1 - Math.exp(-3 * dt));
        Q.premultiply(this.q2);
      } else if (altN < Math.min(4000, nb.R * 0.15) && Math.abs(inp.roll) < 0.1) {
        this.rollLevel(Q, radial, 1 - Math.exp(-0.9 * dt));
      }
    }

    // kecepatan
    const f2 = new THREE.Vector3(0, 0, -1).applyQuaternion(Q);
    const up2 = new THREE.Vector3(0, 1, 0).applyQuaternion(Q);
    let thr = this.throttle;
    if (this.braking) thr = 0;
    const target = thr * thr * lim;
    const vT = f2.multiplyScalar(target);
    if (inp.vert) vT.addScaledVector(up2, inp.vert * Math.min(lim * 0.6, 30));
    const k = this.braking ? 4 : 1.7;
    this.shipVel.lerp(vT, 1 - Math.exp(-k * dt));
    const sp = this.shipVel.length();
    if (sp > lim * 1.02) this.shipVel.multiplyScalar(1 - (1 - lim / sp) * (1 - Math.exp(-4 * dt)));
    this.shipPos.addScaledVector(this.shipVel, dt);

    // tabrakan: benda langit
    this.contact = false;
    let hazard: string | null = null;
    for (const b of this.bodies) {
      const rel = this.v1.copy(this.shipPos).sub(b.pos);
      const d = rel.length();
      const rough = b.R + (b.isTerrain ? b.def.t!.amp * 3 + 100 : 0);
      if (d > rough * 1.05 + 100) continue;
      let minD: number;
      if (b.isSun) {
        if (d < b.R * 1.35) hazard = 'Panas ekstrem — mundur!';
        minD = b.R * 1.02;
      } else if (b.isGas) {
        if (d < b.R * 0.99) hazard = 'Tekanan atmosfer tinggi';
        if (d < b.R * 0.975) hazard = 'Tekanan kritis — naik!';
        minD = b.R * 0.97;
      } else {
        const dl = b.toLocal(this.v2.copy(rel).multiplyScalar(1 / d), this.v3);
        minD = b.surfaceRadius(dl) + GEAR_H;
      }
      if (d < minD) {
        const n = rel.multiplyScalar(1 / d);
        this.shipPos.copy(b.pos).addScaledVector(n, minD);
        const vn = this.shipVel.dot(n);
        if (vn < 0) {
          if (-vn > 4 && !this.prevContact) { this.audio.touch(); this.shake = Math.min(0.15, -vn * 0.01); }
          this.shipVel.addScaledVector(n, -vn);
        }
        if (!b.isSun && !b.isGas) {
          this.contact = true;
          if (this.throttle < 0.03 && !inp.vert) this.shipVel.multiplyScalar(Math.exp(-4 * dt));
        }
        if (b.isGas && vn < 0 && d < b.R * 0.975) this.shipVel.addScaledVector(n, 120 * dt);
        if (b.isSun) this.shipVel.addScaledVector(n, 200 * dt);
      }
    }
    this.prevContact = this.contact;
    this.landed = this.contact && this.shipVel.length() < 5;
    if (this.landed) {
      this.landTimer += dt;
      if (this.landTimer > 1.2 && env.nearest && !env.nearest.landedOn && !env.nearest.isGas && !env.nearest.isSun) {
        env.nearest.landedOn = true;
        env.nearest.visited = true;
        this.toast(`Mendarat di ${env.nearest.def.name}!`, 'discover');
        this.audio.discover();
      }
    } else this.landTimer = 0;
    if (hazard) {
      this.setWarn(hazard, 1);
      if (Math.floor(this.time * 2) % 4 === 0) this.audio.warn();
    }
    // asteroid
    if (this.belt.rocks.length) {
      for (const r of this.belt.rocks) {
        const rel = this.v1.set(this.shipPos.x - r.x, this.shipPos.y - r.y, this.shipPos.z - r.z);
        const d = rel.length();
        if (d < r.r + 10) {
          const n = rel.multiplyScalar(1 / d);
          this.shipPos.set(r.x, r.y, r.z).addScaledVector(n, r.r + 10);
          const vn = this.shipVel.dot(n);
          if (vn < 0) { this.shipVel.addScaledVector(n, -vn * 1.2); this.audio.touch(); this.shake = 0.12; this.setWarn('Tabrakan asteroid', 1.2); }
        }
      }
    }
    // gerak saat EVA / berdiri
    void radial; void f;
  }
  prevContact = false;

  // ------------------------------------------------ berjalan di dalam kapal
  private stepWalk(dt: number) {
    // kamera kepala
    const inp = this.input;
    if (this.mode === 'walk' || this.mode === 'airlock') {
      this.headYaw -= inp.lookDX * 0.005;
      this.headPitch = clamp(this.headPitch - inp.lookDY * 0.005, -1.4, 1.4);
    } else if (this.mode === 'pilot') {
      if (this.lookMode || this.view === 'chase') {
        this.headYaw -= inp.lookDX * 0.005;
        this.headPitch = clamp(this.headPitch - inp.lookDY * 0.005, this.view === 'chase' ? -1.3 : -1.2, 1.3);
        if (this.view === 'cockpit') this.headYaw = clamp(this.headYaw, -2.4, 2.4);
      } else {
        this.headYaw *= Math.exp(-2.5 * dt);
        this.headPitch *= Math.exp(-2.5 * dt);
      }
    }
    if (this.mode !== 'walk') return;
    const sp = 2.3 * (inp.run ? 1.5 : 1);
    const yaw = this.headYaw;
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw), rx = Math.cos(yaw), rz = -Math.sin(yaw);
    let mx = fx * inp.moveY + rx * inp.moveX, mz = fz * inp.moveY + rz * inp.moveX;
    const ml = Math.hypot(mx, mz);
    if (ml > 1) { mx /= ml; mz /= ml; }
    const nx = this.walkPos.x + mx * sp * dt, nz = this.walkPos.z + mz * sp * dt;
    if (!this.blocked(nx, this.walkPos.z)) this.walkPos.x = nx;
    if (!this.blocked(this.walkPos.x, nz)) this.walkPos.z = nz;
  }

  private blocked(x: number, z: number) {
    const r = 0.28;
    if (x < -1.7 || x > 1.7 || z < -4.2 || z > 5.65) return true;
    for (const c of this.rig.colliders) {
      if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r) return true;
    }
    return false;
  }

  // ------------------------------------------------ urutan airlock
  private stepSequence(dt: number) {
    const s = this.seq;
    const lamp = this.rig.hatchLamp.material as THREE.MeshBasicMaterial;
    if (!s) {
      lamp.color.setHex(this.mode === 'eva' ? 0x40ff90 : 0xff3a30);
      this.fade = Math.max(0, this.fade - dt * 2);
      return;
    }
    s.t += dt;
    const blink = Math.floor(s.t * 4) % 2 === 0;
    lamp.color.setHex(blink ? 0xffb030 : 0x331100);
    this.rig.lights.airlock.color.setHex(blink ? 0xff6a40 : 0xffffff);
    if (s.type === 'exit') {
      if (s.t > 0.8 && !s.done1) { s.done1 = true; s.label = 'Depresurisasi…'; this.audio.hiss(2.2); }
      if (s.t > 3.2 && !s.done2) { s.done2 = true; s.label = 'Palka terbuka'; this.audio.thunk(); }
      if (s.t > 3.5) this.fade = Math.min(1, (s.t - 3.5) * 3);
      if (s.t > 4.1 && !s.done3) {
        s.done3 = true;
        this.beginEva();
        this.seq = null;
        this.rig.lights.airlock.color.setHex(0xffffff);
      }
    } else {
      if (s.t < 0.5) this.fade = Math.min(1, s.t * 3);
      if (s.t > 0.6 && !s.done1) { s.done1 = true; s.label = 'Pressurisasi…'; this.audio.thunk(); this.audio.hiss(2.2); this.mode = 'airlock'; this.walkPos.copy(AIRLOCK_IN); this.walkPos.x = 1.1; this.headYaw = Math.PI / 2; this.headPitch = 0; }
      if (s.t > 3.2 && !s.done2) { s.done2 = true; s.label = 'Aman — selamat datang kembali'; this.audio.open(); }
      if (s.t > 3.2) this.fade = Math.max(0, 1 - (s.t - 3.2) * 2.5);
      if (s.t > 3.7 && !s.done3) {
        s.done3 = true;
        this.mode = 'walk';
        this.seq = null;
        this.rig.lights.airlock.color.setHex(0xffffff);
      }
    }
  }

  private beginEva() {
    const Q = this.shipQuat;
    const y = this.landed ? -GEAR_H + 1.8 : 1.0;
    this.v1.set(HATCH_OUT.x, y, HATCH_OUT.z).applyQuaternion(Q);
    this.astro.pos.copy(this.shipPos).add(this.v1);
    this.astro.vel.copy(this.shipVel);
    this.q1.setFromAxisAngle(Y, -Math.PI / 2);
    this.astro.quat.copy(Q).multiply(this.q1);
    this.astro.grounded = false;
    this.mode = 'eva';
    this.view = 'cockpit';
    this.input.moveX = 0; this.input.moveY = 0;
    this.toast('Berjalan di luar angkasa — dengan jetpack', 'info');
  }

  // ------------------------------------------------ astronot (EVA)
  private stepAstro(dt: number) {
    const A = this.astro;
    const inp = this.input;
    const env = this.envCam;
    this.computeEnv(A.pos, env);
    const b = env.nearest;
    const Qa = A.quat;
    // kapal diam
    this.shipVel.multiplyScalar(Math.exp(-3 * dt));
    this.shipPos.addScaledVector(this.shipVel, dt);
    if (this.seq) {
      A.vel.multiplyScalar(Math.exp(-4 * dt));
      A.pos.addScaledVector(A.vel, dt);
      return;
    }

    let upW = this.v1.set(0, 1, 0).applyQuaternion(Qa);
    let gfac = 0, g0 = 0, isTer = false;
    let dirW = new THREE.Vector3(0, 1, 0);
    if (b) {
      dirW = new THREE.Vector3().copy(A.pos).sub(b.pos).normalize();
      g0 = b.def.g;
      isTer = b.isTerrain;
      if (isTer) gfac = clamp(1 - (env.alt - 300) / 700);
      upW = dirW.clone();
    }
    A.gfac = gfac; A.g = g0;
    const gravMode = gfac > 0.25 && isTer;

    // pandangan
    if (gravMode) {
      this.q1.setFromAxisAngle(upW, -inp.lookDX * 0.005);
      Qa.premultiply(this.q1);
      const f0 = this.v2.set(0, 0, -1).applyQuaternion(Qa);
      const pitchNow = Math.asin(clamp(f0.dot(upW), -1, 1));
      const dp = clamp(-inp.lookDY * 0.005, -1.45 - pitchNow, 1.45 - pitchNow);
      this.q2.setFromAxisAngle(X, dp);
      Qa.multiply(this.q2);
      this.rollLevel(Qa, upW, 1 - Math.exp(-6 * dt));
    } else {
      this.q1.setFromAxisAngle(Y, -inp.lookDX * 0.005);
      this.q2.setFromAxisAngle(X, -inp.lookDY * 0.005);
      Qa.multiply(this.q1).multiply(this.q2);
    }
    Qa.normalize();
    const fA = new THREE.Vector3(0, 0, -1).applyQuaternion(Qa);
    const rA = new THREE.Vector3(1, 0, 0).applyQuaternion(Qa);
    const uA = new THREE.Vector3(0, 1, 0).applyQuaternion(Qa);

    // tali kembali
    const hatchW = new THREE.Vector3(HATCH_OUT.x - 0.9, 0.9, HATCH_OUT.z).applyQuaternion(this.shipQuat).add(this.shipPos);
    if (this.autoReturn) {
      const to = hatchW.clone().sub(A.pos);
      const d = to.length();
      const sp = clamp(d * 0.6, 6, 80);
      A.vel.copy(to.normalize().multiplyScalar(Math.min(sp, d / dt)));
      A.pos.addScaledVector(A.vel, dt);
      if (d < 2.5) { this.autoReturn = false; this.startEnter(); }
      return;
    }

    if (gravMode && b) {
      // jalan kaki
      const fH = fA.clone().addScaledVector(upW, -fA.dot(upW));
      if (fH.lengthSq() < 0.01) fH.copy(uA).addScaledVector(upW, -uA.dot(upW));
      fH.normalize();
      const rH = fH.clone().cross(upW).normalize();
      const sp = inp.run ? 8 : 4.2;
      const wish = fH.multiplyScalar(inp.moveY).addScaledVector(rH, inp.moveX);
      if (wish.length() > 1) wish.normalize();
      let vv = A.vel.dot(upW);
      const vh = A.vel.clone().addScaledVector(upW, -vv);
      const acc = A.grounded ? 12 : 1.2;
      vh.lerp(wish.multiplyScalar(sp), 1 - Math.exp(-acc * dt));
      if (inp.jetUp) vv += (6 + g0 * gfac) * dt;
      if (inp.jetDown) vv -= 6 * dt;
      vv -= g0 * gfac * dt;
      if (inp.jump && A.grounded) { vv += clamp(Math.sqrt(2 * g0 * 1.4), 2.4, 7); this.audio.jump(); }
      A.vel.copy(vh).addScaledVector(upW, vv);
    } else {
      // gravitasi nol: jetpack
      const acc = 5;
      const th = new THREE.Vector3().addScaledVector(fA, inp.moveY).addScaledVector(rA, inp.moveX);
      th.addScaledVector(uA, (inp.jetUp ? 1 : 0) - (inp.jetDown ? 1 : 0));
      if (th.lengthSq() > 0) A.vel.addScaledVector(th.normalize().multiplyScalar(acc * dt), 1);
      if (this.braking || (!th.lengthSq() && this.keys.has('x'))) A.vel.multiplyScalar(Math.exp(-2.5 * dt));
      else A.vel.multiplyScalar(Math.exp(-0.12 * dt));
      if (b && isTer && gfac > 0) A.vel.addScaledVector(upW, -g0 * gfac * dt);
      const s = A.vel.length();
      if (s > 80) A.vel.multiplyScalar(80 / s);
    }
    A.pos.addScaledVector(A.vel, dt);

    // tanah
    A.grounded = false;
    if (b && isTer) {
      const rel = this.v2.copy(A.pos).sub(b.pos);
      const d = rel.length();
      const dl = b.toLocal(rel.clone().multiplyScalar(1 / d), this.v3);
      const sr = b.surfaceRadius(dl) + 1.75;
      if (d < sr) {
        const n = rel.multiplyScalar(1 / d);
        A.pos.copy(b.pos).addScaledVector(n, sr);
        const vn = A.vel.dot(n);
        if (vn < 0) A.vel.addScaledVector(n, -vn);
        A.grounded = true;
      }
    }

    // badan kapal
    const loc = this.v2.copy(A.pos).sub(this.shipPos).applyQuaternion(this.q1.copy(this.shipQuat).invert());
    const lx = 2.45, y0 = -1.5, y1 = 4.8, z0 = -8, z1 = 7.6;
    if (Math.abs(loc.x) < lx && loc.y > y0 && loc.y < y1 && loc.z > z0 && loc.z < z1) {
      const px = lx - Math.abs(loc.x), py1 = y1 - loc.y, pz0 = loc.z - z0, pz1 = z1 - loc.z, py0 = loc.y - y0;
      const m = Math.min(px, py1, pz0, pz1, py0);
      if (m === px) loc.x = Math.sign(loc.x || 1) * lx;
      else if (m === py1) loc.y = y1;
      else if (m === py0) loc.y = y0;
      else if (m === pz0) loc.z = z0;
      else loc.z = z1;
      loc.applyQuaternion(this.shipQuat);
      A.pos.copy(this.shipPos).add(loc);
      A.vel.multiplyScalar(0.5);
      if (m === py1 && b && gravMode) A.grounded = true;
    }
    if (A.pos.distanceTo(this.shipPos) > 1500 && Math.floor(this.time * 2) % 10 === 0) this.setWarn('Jauh dari kapal — tekan TARIK', 2);
  }

  // =============================================================== KAMERA & DUNIA
  private cameraUpdate(dt: number) {
    const mode = this.mode;
    const cam = this.camera;
    // transisi duduk/berdiri
    const targetEye = mode === 'pilot' ? PILOT_EYE : this.walkPos;
    if (mode === 'eva') this.origin.copy(this.astro.pos);
    else this.origin.copy(this.shipPos);
    this.eyeLocal.lerp(targetEye, 1 - Math.exp(-(mode === 'airlock' ? 12 : 6) * dt));
    let shake = this.shake;
    this.shake = Math.max(0, this.shake - dt * 0.2);
    shake += this.heat * 0.012 + (mode === 'pilot' ? this.throttle * 0.0015 * (this.boost ? 3 : 1) : 0);
    if (this.seq) shake += 0.004;

    const Q = this.shipQuat;
    if (mode === 'eva') {
      this.camP.set(0, 0, 0);
      this.camQ.copy(this.astro.quat);
    } else if (this.view === 'chase' && mode === 'pilot') {
      const d = 22;
      this.q1.setFromAxisAngle(Y, this.headYaw);
      this.q2.setFromAxisAngle(X, -this.headPitch);
      const off = this.v1.set(0, 3.5, d).applyQuaternion(this.q2).applyQuaternion(this.q1);
      const rel = off.clone().applyQuaternion(Q);
      this.camP.copy(rel);
      this.m4.lookAt(rel, this.v2.set(0, 1.2, 0).applyQuaternion(Q), this.v3.set(0, 1, 0).applyQuaternion(Q));
      this.camQ.setFromRotationMatrix(this.m4);
    } else {
      this.q1.setFromAxisAngle(Y, this.headYaw);
      this.q2.setFromAxisAngle(X, this.headPitch);
      const bob = mode === 'walk' && (Math.abs(this.input.moveX) + Math.abs(this.input.moveY) > 0.2) ? Math.sin(this.time * 8) * 0.025 : 0;
      this.camP.copy(this.eyeLocal);
      this.camP.y += bob;
      this.camP.applyQuaternion(Q);
      this.camQ.copy(Q).multiply(this.q1).multiply(this.q2);
    }
    cam.position.copy(this.camP);
    cam.quaternion.copy(this.camQ);
    if (shake > 0) {
      cam.position.x += (Math.random() - 0.5) * shake;
      cam.position.y += (Math.random() - 0.5) * shake;
      cam.position.z += (Math.random() - 0.5) * shake;
    }
    // FOV mengikuti kecepatan
    const sp = mode === 'eva' ? this.astro.vel.length() : this.shipVel.length();
    const fovT = this.baseFov + clamp(Math.log10(1 + sp / 200) / 3.2) * 14 + (this.boost ? 4 : 0);
    cam.fov += (fovT - cam.fov) * (1 - Math.exp(-3 * dt));
    cam.updateProjectionMatrix();
    cam.updateMatrixWorld(true);

    // kapal di adegan interior
    this.rig.group.position.set(this.shipPos.x - this.origin.x, this.shipPos.y - this.origin.y, this.shipPos.z - this.origin.z);
    this.rig.group.quaternion.copy(Q);
  }

  private worldUpdate(dt: number) {
    const cam = this.camera;
    const origin = this.origin;
    const camWorld = this.camP.clone().add(origin);
    if (this.mode !== 'eva') this.envCam = Object.assign(this.envCam, this.env);
    const env = this.envCam;

    // sinkron render semua benda
    for (const b of this.bodies) b.syncRender(origin);
    this.station.position.copy(this.landmarks[0].pos).sub(origin);
    const stRing = (this.station as any).ring as THREE.Object3D;
    stRing.rotation.y += dt * 0.12;
    const bumi = this.byId.get('bumi')!;
    this.station.quaternion.setFromAxisAngle(Y, 0.5 + this.time * 0.0008 + bumi.def.phase);
    ((this.station as any).lamp as THREE.Mesh).visible = Math.floor(this.time * 1.5) % 2 === 0;
    this.voyager.position.copy(this.landmarks[1].pos).sub(origin);
    this.voyager.rotation.y += dt * 0.02;

    // arah matahari & cahaya
    const sunRel = this.v1.copy(this.sun.pos).sub(origin);
    this.sunLight.position.copy(sunRel);
    const sdShip = sunRel.clone().add(origin).sub(this.shipPos).normalize();
    this.rig.sun.position.copy(sdShip).multiplyScalar(100);
    const outside = this.mode === 'eva' || (this.view === 'chase');
    this.rig.sun.intensity += ((outside ? 3.4 : 0.35) - this.rig.sun.intensity) * (1 - Math.exp(-4 * dt));
    const hemi = this.rig.lights.hemi;
    hemi.intensity += ((this.mode === 'eva' ? 0.45 : 2.1) - hemi.intensity) * (1 - Math.exp(-4 * dt));

    // LOD per benda
    const fwdW = this.v2.set(0, 0, -1).applyQuaternion(this.camQ);
    const order: { b: Body; r: number }[] = [];
    for (const b of this.bodies) {
      const rel = this.v3.copy(camWorld).sub(b.pos);
      const sunDir = this.v4.copy(this.sun.pos).sub(b.pos).normalize();
      let dens = 0;
      if (env.atmBody === b) dens = clamp(env.dens, 0, 1.5);
      b.updateShading(rel, sunDir, this.time, dens);
      if (b.isTerrain) {
        const cl = b.toLocal(rel, new THREE.Vector3());
        const fl = b.toLocal(fwdW, new THREE.Vector3());
        b.updateLOD(cl, fl, this.frameN);
        order.push({ b, r: cl.length() / b.R });
      }
    }
    order.sort((a, c) => a.r - c.r);
    let budget = this.buildBudget;
    const t0 = performance.now();
    for (const o of order) {
      if (o.r > 80) break;
      const used = performance.now() - t0;
      if (used >= budget) break;
      o.b.buildPending(Math.max(1, budget - used));
    }

    // langit / kabut
    for (const b of this.bodies) { b.fogD.value = 0; if (b.gasU) b.gasU.uFog.value = 0; }
    let skyBright = 0;
    this.heat = 0;
    if (env.atmBody) {
      const b = env.atmBody;
      const atm = b.def.atm!;
      const up = this.v3.copy(camWorld).sub(b.pos).normalize();
      const sd = this.v4.copy(this.sun.pos).sub(b.pos).normalize();
      const sl = up.dot(sd);
      const sunlit = smooth(-0.18, 0.3, sl);
      const dens = Math.min(env.dens, 1.2);
      skyBright = clamp(dens * sunlit * 1.5);
      b.fogD.value = dens * atm.dens * (0.4 + 0.6 * sunlit);
      const sunset = smooth(-0.12, 0.04, sl) * (1 - smooth(0.04, 0.32, sl));
      const c = b.fogC.value;
      const base = 0.03 + 0.97 * sunlit;
      c.setRGB(
        (atm.fog[0] * (1 - sunset * 0.5) + 0.95 * sunset * 0.5) * base,
        (atm.fog[1] * (1 - sunset * 0.5) + 0.5 * sunset * 0.5) * base,
        (atm.fog[2] * (1 - sunset * 0.5) + 0.25 * sunset * 0.5) * base
      );
      if (b.isGas && env.gasDepth > 0 && b.gasU) b.gasU.uFog.value = smooth(0, 0.02, env.gasDepth);
      this.heat = this.mode === 'eva' ? 0 : clamp((this.shipVel.length() * Math.min(dens, 1)) / 900);
    }
    this.stars.starMat.opacity = 1 - skyBright;
    this.stars.mwMat.opacity = 1 - skyBright;
    this.stars.group.position.copy(cam.position);
    this.ambient.intensity = 0.16 + 1.1 * skyBright;
    this.ambient.color.setRGB(0.55, 0.62, 0.8);

    // debu & sabuk
    const velRef = this.mode === 'eva' ? this.astro.vel : this.shipVel;
    const spd = velRef.length();
    this.dust.update(origin, velRef, clamp(Math.log10(1 + spd) / 3) * 0.55 * (1 - skyBright * 0.8));
    this.belt.update(origin);
    if (this.belt.inside && !this.beltToast) { this.beltToast = true; this.toast('Memasuki Sabuk Asteroid — hati-hati!', 'warn'); this.audio.warn(); }
    if (!this.belt.inside && this.beltToast && Math.hypot(origin.x, origin.z) < 14e6) this.beltToast = false;

    // flare & silau
    this.updateFlares(camWorld, fwdW);
  }

  private updateFlares(camWorld: THREE.Vector3, fwdW: THREE.Vector3) {
    const sunRel = this.v1.copy(this.sun.pos).sub(camWorld);
    const dist = sunRel.length();
    const dir = sunRel.clone().normalize();
    // tertutup?
    let occluded = false;
    for (const b of this.bodies) {
      if (b === this.sun) continue;
      const c = this.v2.copy(b.pos).sub(camWorld);
      const t = c.dot(dir);
      if (t <= 0 || t > dist) continue;
      const dd = Math.sqrt(Math.max(0, c.lengthSq() - t * t));
      if (dd < b.R * 0.995) { occluded = true; break; }
    }
    const facing = dir.dot(fwdW);
    const ndc = dir.clone().multiplyScalar(1000).add(this.camera.position).project(this.camera);
    const inFront = facing > 0.2;
    const edge = 1 - clamp((Math.max(Math.abs(ndc.x), Math.abs(ndc.y)) - 0.7) / 0.6);
    const vis = occluded || !inFront ? 0 : edge;
    const dFade = clamp(1.4 - Math.log10(dist / 1e6) * 0.5, 0.25, 1);
    this.glare = vis * smooth(0.82, 1, facing) * dFade;
    for (const f of this.flares) {
      const nx = ndc.x * f.k, ny = ndc.y * f.k;
      const w = this.v3.set(nx, ny, 0.5).unproject(this.camera).sub(this.camera.position).normalize();
      f.s.position.copy(this.camera.position).addScaledVector(w, 100);
      const sc = f.base * (f.k === 1 ? 1 : 0.6 + 0.4 * (1 - Math.abs(ndc.x)));
      f.s.scale.setScalar(sc * 0.4);
      (f.s.material as THREE.SpriteMaterial).opacity = vis * dFade * (f.k === 1 ? 0.5 : 0.28);
    }
  }

  private progressCheck(dt: number) {
    this.lastDiscCheck += dt;
    if (this.lastDiscCheck < 0.5) return;
    this.lastDiscCheck = 0;
    const o = this.mode === 'eva' ? this.astro.pos : this.shipPos;
    for (const b of this.bodies) {
      const d = o.distanceTo(b.pos);
      if (!b.discovered && d < b.R * (b.isSun ? 5 : 8) + 30000) {
        b.discovered = true;
        this.toast(`Penemuan: ${b.def.name} (${b.def.kind})`, 'discover');
        this.audio.discover();
      }
      if (!b.visited && d - b.R < Math.max(4000, b.R * 0.12)) {
        b.visited = true;
        if (!b.isSun) this.toast(`Orbit rendah: ${b.def.name}`, 'info');
      }
    }
  }

  // =============================================================== PROMPT, HUD
  private getPrompt(): { text: string; action: string } | null {
    if (this.seq || this.mode === 'airlock') return null;
    if (this.mode === 'walk') {
      const dx = this.walkPos.x - SEAT_POS.x, dz = this.walkPos.z - SEAT_POS.z;
      if (Math.hypot(dx, dz) < 1.7) return { text: 'Duduk di kursi pilot', action: 'sit' };
      if (this.walkPos.x > 0.7 && this.walkPos.z > 4.0) return { text: 'Keluar kapal (EVA)', action: 'exit' };
    }
    if (this.mode === 'eva') {
      const hatchW = this.v1.set(HATCH_OUT.x, 0.9, HATCH_OUT.z).applyQuaternion(this.shipQuat).add(this.shipPos);
      if (this.astro.pos.distanceTo(hatchW) < 7) return { text: 'Masuk kapal', action: 'enter' };
      if (this.astro.grounded && this.envCam.nearest?.isTerrain) return { text: 'Tancapkan bendera', action: 'flag' };
    }
    return null;
  }

  private makeHud(): Hud {
    const mode = this.mode;
    const t = this.getTarget();
    const o = mode === 'eva' ? this.astro.pos : this.shipPos;
    let marker: Hud['marker'] = null;
    let tdist = 0;
    if (t) {
      const rel = this.v1.copy(t.pos).sub(this.origin);
      tdist = Math.max(0, rel.length() - t.radius);
      const cv = rel.clone().applyMatrix4(this.camera.matrixWorldInverse);
      const behind = cv.z > 0;
      const nd = rel.clone().project(this.camera);
      marker = { x: behind ? -nd.x : nd.x, y: behind ? -nd.y : nd.y, behind };
    }
    const env = mode === 'eva' ? this.envCam : this.env;
    let disc = 0, vis = 0, land = 0, fl = 0;
    for (const b of this.bodies) { if (b.discovered) disc++; if (b.visited) vis++; if (b.landedOn) land++; if (b.flagged) fl++; }
    const spd = mode === 'eva' ? this.astro.vel.length() : this.shipVel.length();
    void o;
    return {
      mode, view: this.view, look: this.lookMode, speed: spd, alt: env.alt, nearest: env.nearest ? env.nearest.def.name : '—',
      throttle: this.throttle, limit: this.env.limit, landed: this.landed, grounded: this.astro.grounded,
      target: t ? { id: t.id, name: t.name, dist: tdist } : null, marker, autopilot: this.autopilot,
      prompt: this.getPrompt(), oxygen: this.oxygen, heat: this.heat, glare: this.glare, atmo: clamp(env.dens),
      gasDepth: this.envCam.gasDepth, warn: this.warn, seq: this.seq ? this.seq.label : null, fade: this.fade,
      nearSurface: env.alt < 4000 && !!env.nearest && !env.nearest.isSun, counts: { disc, visit: vis, landed: land, flags: fl, total: this.bodies.length },
      gravity: this.astro.g * this.astro.gfac, boost: this.boost, muted: this.audio.muted,
    };
  }

  // =============================================================== LAYAR KOKPIT
  private mapList: { b: Body; col: string; r: number }[] | null = null;
  private drawScreens() {
    if (!this.mapList) {
      this.mapList = this.bodies.filter((b) => !b.def.parent || b.def.parent === 'matahari').map((b) => ({
        b, r: b.isSun ? 5 : b.R > 200000 ? 3.2 : 2.2,
        col: b.isSun ? '#ffd060' : b.def.id === 'bumi' ? '#4aa0ff' : b.def.id === 'mars' ? '#e0703a' : b.isGas ? '#e0c090' : '#cfd6dd',
      }));
    }
    const inv = this.q1.copy(this.shipQuat).invert();
    const blips: Blip[] = [];
    for (const t of this.allTargets()) {
      const v = this.v1.copy(t.pos).sub(this.shipPos).applyQuaternion(inv);
      const len = v.length();
      if (len < 1) continue;
      const th = Math.acos(clamp(-v.z / len, -1, 1));
      const phi = Math.atan2(v.y, v.x);
      const rad = th / Math.PI;
      blips.push({
        x: Math.cos(phi) * rad, y: -Math.sin(phi) * rad, sel: t.id === this.targetId,
        col: t.body ? (t.body.isSun ? '#ffd060' : t.body.def.parent && t.body.def.parent !== 'matahari' ? '#aab4bf' : '#45e3ff') : '#ff9a3c',
        r: t.body?.isSun ? 4.5 : t.body && t.body.R > 100000 ? 3.5 : 2.4,
      });
    }
    const f = this.v2.set(0, 0, -1).applyQuaternion(this.shipQuat);
    const nb = this.env.nearest;
    const rad = nb ? this.v3.copy(this.shipPos).sub(nb.pos).normalize() : new THREE.Vector3(0, 1, 0);
    const upS = this.v4.set(0, 1, 0).applyQuaternion(this.shipQuat);
    const rS = new THREE.Vector3(1, 0, 0).applyQuaternion(this.shipQuat);
    const t = this.getTarget();
    const data: ScreenData = {
      t: this.time, blips,
      pitch: Math.asin(clamp(f.dot(rad), -1, 1)),
      roll: Math.atan2(rS.dot(rad), upS.dot(rad)),
      speed: this.shipVel.length(), alt: this.env.alt, throttle: this.throttle,
      targetName: t ? t.name : '', targetDist: t ? Math.max(0, t.pos.distanceTo(this.shipPos) - t.radius) : 0,
      ap: this.autopilot, oxygen: this.oxygen, hull: this.hull, energy: this.energy,
      nearest: nb ? nb.def.name : '—', dens: this.env.dens,
      mapBodies: this.mapList.map((m) => ({ x: m.b.pos.x, z: m.b.pos.z, r: m.r, col: m.col, name: m.b.def.name, parentless: true, sel: m.b.id === this.targetId })),
      ship: { x: this.shipPos.x, z: this.shipPos.z, h: Math.atan2(f.z, f.x) },
      warn: this.warn,
    };
    const s = this.rig.screens;
    const ph = this.frameN % 4;
    if (ph === 0) drawRadar(s.radar, data);
    else if (ph === 1) drawNav(s.nav, data);
    else if (ph === 2) drawStatus(s.status, data);
    else drawMap(s.map, data);
  }

  // =============================================================== RENDER
  private animateRig() {
    const rig = this.rig;
    const t = this.time;
    // tuas gas & yoke
    rig.throttleLever.rotation.x += (-this.throttle * 0.9 - rig.throttleLever.rotation.x) * 0.2;
    rig.yoke.rotation.z += (-this.input.steerX * 0.5 - rig.yoke.rotation.z) * 0.2;
    rig.yoke.rotation.x += (-this.input.steerY * 0.25 - rig.yoke.rotation.x) * 0.2;
    // lampu berkedip
    for (const b of rig.blinkers) {
      const on = Math.sin(t * b.speed * 3 + b.phase) > -0.2;
      (b.mesh.material as THREE.MeshBasicMaterial).opacity = 1;
      b.mesh.scale.setScalar(on ? 1 : 0.35);
    }
    // holo
    rig.holo.rotation.y = t * 0.1;
    const sunPos = this.sun.pos;
    rig.holoPlanets.forEach((m, id) => {
      const b = this.byId.get(id);
      if (!b) return;
      const dx = b.pos.x - sunPos.x, dz = b.pos.z - sunPos.z;
      const r = Math.hypot(dx, dz);
      const rr = 0.06 + Math.sqrt(r / 68e6) * 0.46;
      const a = Math.atan2(dz, dx);
      m.position.set(Math.cos(a) * rr, 0, Math.sin(a) * rr);
    });
    {
      const dx = this.shipPos.x - sunPos.x, dz = this.shipPos.z - sunPos.z;
      const r = Math.hypot(dx, dz);
      const rr = 0.06 + Math.sqrt(r / 68e6) * 0.46;
      const a = Math.atan2(dz, dx);
      rig.holoShip.position.set(Math.cos(a) * rr, 0.02 + Math.sin(t * 3) * 0.005, Math.sin(a) * rr);
      rig.holoShip.scale.setScalar(Math.floor(t * 2) % 2 ? 1 : 0.5);
    }
    // mesin
    const sp = this.shipVel.length();
    const thr = this.mode === 'eva' ? 0 : Math.max(this.throttle, this.braking ? 0 : clamp(sp / Math.max(1, this.env.limit)) * 0.4);
    const flick = 0.85 + Math.random() * 0.3;
    rig.engineGlows.forEach((g, i) => {
      const core = i % 2 === 1;
      (g.material as THREE.MeshBasicMaterial).opacity = (core ? 0.55 : 0.4) * Math.min(1, thr * 1.4) * flick;
      g.scale.set(1, 0.4 + thr * (this.boost ? 2.2 : 1.1) * flick, 1);
    });
    rig.engineLight.intensity = thr * 25 * flick;
    rig.fans.forEach((f, i) => { f.rotation.z += (i ? -1 : 1) * 0.02 * (1 + thr * 8); });
    (rig.reactor.material as THREE.MeshBasicMaterial).opacity = 0.65 + Math.sin(t * 2) * 0.15 + thr * 0.2;
    // kaki pendarat: tampak bila rendah/ landed
    const gearOut = this.env.alt < 3000 ? 1 : 0;
    rig.legs.forEach((l) => {
      const cur = l.scale.y;
      l.scale.y += (gearOut ? 1 - cur : 0.15 - cur) * 0.08;
    });
    // lampu kokpit menyesuaikan
    rig.lights.cockpit.intensity = 3.4 + Math.sin(t * 5) * 0.1 * this.heat + this.heat * 4;
    if (this.heat > 0.1) rig.lights.cockpit.color.setRGB(1, 0.6 + 0.4 * (1 - this.heat), 0.4 + 0.6 * (1 - this.heat));
    else rig.lights.cockpit.color.setHex(0x88ccff);
  }

  render() {
    if (!this.renderer) return;
    this.animateRig();
    this.renderer.clear();
    this.renderer.render(this.world, this.camera);
    this.renderer.clearDepth();
    this.renderer.render(this.shipScene, this.camera);
  }
}
