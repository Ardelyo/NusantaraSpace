import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine, type Hud } from './game/engine';
import { fmtDist, fmtSpeed } from './game/screens';
import MapPanel from './MapPanel';

interface Toast { id: number; text: string; kind: 'info' | 'discover' | 'warn' }
const clamp = (v: number, a = -1, b = 1) => Math.max(a, Math.min(b, v));

function HoldBtn({ onDown, onUp, children, className = '', active = false }: { onDown: () => void; onUp: () => void; children: React.ReactNode; className?: string; active?: boolean }) {
  return (
    <button
      className={`select-none touch-none flex items-center justify-center rounded-full border backdrop-blur-sm active:scale-95 transition ${active ? 'border-amber-300 bg-amber-400/30 text-amber-100' : 'border-cyan-300/40 bg-black/40 text-cyan-100'} ${className}`}
      onPointerDown={(e) => { e.stopPropagation(); (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId); onDown(); }}
      onPointerUp={(e) => { e.stopPropagation(); onUp(); }}
      onPointerCancel={onUp}
      onLostPointerCapture={onUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

function TapBtn({ onTap, children, className = '', active = false }: { onTap: () => void; children: React.ReactNode; className?: string; active?: boolean }) {
  return (
    <button
      className={`select-none touch-none flex items-center justify-center rounded-full border backdrop-blur-sm active:scale-95 transition ${active ? 'border-amber-300 bg-amber-400/30 text-amber-100' : 'border-cyan-300/40 bg-black/40 text-cyan-100'} ${className}`}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => { e.stopPropagation(); onTap(); }}
    >
      {children}
    </button>
  );
}

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [progress, setProgress] = useState({ p: 0, label: 'Memulai' });
  const [ready, setReady] = useState(false);
  const [started, setStarted] = useState(false);
  const [hud, setHud] = useState<Hud | null>(null);
  const hudRef = useRef<Hud | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [showMap, setShowMap] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [tip, setTip] = useState(true);
  const [stick, setStick] = useState<{ L?: { cx: number; cy: number; x: number; y: number }; R?: { cx: number; cy: number; x: number; y: number } }>({});
  const [flash, setFlash] = useState(0);
  const toastId = useRef(0);
  const ptrs = useRef(new Map<number, { zone: 'L' | 'R'; sx: number; sy: number; lx: number; ly: number; thr: number }>());
  hudRef.current = hud;

  useEffect(() => {
    if (!mountRef.current) return;
    let dead = false;
    const eng = new Engine(mountRef.current, {
      onHud: (h) => { if (!dead) setHud(h); },
      onToast: (text, kind) => {
        if (dead) return;
        const id = ++toastId.current;
        setToasts((t) => [...t.slice(-2), { id, text, kind }]);
        setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === 'discover' ? 4200 : 3200);
      },
      onProgress: (p, label) => { if (!dead) setProgress({ p, label }); },
    });
    engineRef.current = eng;
    eng.init().then(() => { if (!dead) { setReady(true); eng.start(); } }).catch((e) => { console.error(e); setProgress({ p: 1, label: 'Gagal memuat: ' + (e?.message || e) }); });
    return () => { dead = true; eng.dispose(); engineRef.current = null; };
  }, []);

  // kilat di dalam gas raksasa
  useEffect(() => {
    if (!hud || hud.gasDepth < 0.004) return;
    if (Math.random() < 0.18) { setFlash(0.6); setTimeout(() => setFlash(0), 90); }
  }, [hud]);

  const eng = () => engineRef.current!;

  // ---------------- gestur ----------------
  const onDown = useCallback((e: React.PointerEvent) => {
    if (e.target !== e.currentTarget || !started) return;
    const zone: 'L' | 'R' = e.clientX < window.innerWidth * 0.5 ? 'L' : 'R';
    for (const p of ptrs.current.values()) if (p.zone === zone) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    ptrs.current.set(e.pointerId, { zone, sx: e.clientX, sy: e.clientY, lx: e.clientX, ly: e.clientY, thr: eng().throttle });
    const h = hudRef.current;
    const showStick = zone === 'R' ? h?.mode === 'pilot' && !h.look : h?.mode === 'walk' || h?.mode === 'eva';
    if (showStick) setStick((s) => ({ ...s, [zone]: { cx: e.clientX, cy: e.clientY, x: 0, y: 0 } }));
  }, [started]);

  const onMove = useCallback((e: React.PointerEvent) => {
    const p = ptrs.current.get(e.pointerId);
    if (!p) return;
    const en = engineRef.current;
    const h = hudRef.current;
    if (!en || !h) return;
    const dx = e.clientX - p.sx, dy = e.clientY - p.sy;
    if (p.zone === 'L') {
      if (h.mode === 'pilot') en.setThrottle(clamp(p.thr - dy / (window.innerHeight * 0.38), 0, 1));
      else if (h.mode === 'walk' || h.mode === 'eva') {
        const x = clamp(dx / 56), y = clamp(-dy / 56);
        en.setMove(x, y, Math.hypot(x, y) > 0.95);
        setStick((s) => ({ ...s, L: { cx: p.sx, cy: p.sy, x: clamp(dx, -56, 56), y: clamp(dy, -56, 56) } }));
      }
    } else {
      if (h.mode === 'pilot' && !h.look) {
        en.setSteer(clamp(dx / 70), clamp(-dy / 70));
        setStick((s) => ({ ...s, R: { cx: p.sx, cy: p.sy, x: clamp(dx, -70, 70), y: clamp(dy, -70, 70) } }));
      } else en.addLook(e.clientX - p.lx, e.clientY - p.ly);
    }
    p.lx = e.clientX; p.ly = e.clientY;
  }, []);

  const onUp = useCallback((e: React.PointerEvent) => {
    const p = ptrs.current.get(e.pointerId);
    if (!p) return;
    ptrs.current.delete(e.pointerId);
    const en = engineRef.current;
    if (p.zone === 'L') en?.setMove(0, 0);
    else en?.setSteer(0, 0);
    setStick((s) => ({ ...s, [p.zone]: undefined }));
  }, []);

  const start = () => {
    eng().startAudio();
    setStarted(true);
    setTimeout(() => setTip(false), 16000);
    try { document.documentElement.requestFullscreen?.().catch(() => {}); } catch { /* abaikan */ }
  };

  const h = hud;
  const mode = h?.mode;
  const marker = h?.marker;
  let markerEl: React.ReactNode = null;
  if (marker && h?.target && started && mode !== 'airlock') {
    const edge = marker.behind || Math.abs(marker.x) > 0.9 || Math.abs(marker.y) > 0.82;
    let mx = marker.x, my = marker.y, ang = 0;
    if (edge) {
      if (mx === 0 && my === 0) my = -1;
      const s = Math.min(0.88 / Math.max(Math.abs(mx), 1e-6), 0.8 / Math.max(Math.abs(my), 1e-6));
      ang = (Math.atan2(my, mx) * 180) / Math.PI;
      mx *= s; my *= s;
    }
    markerEl = (
      <div className="pointer-events-none absolute z-10" style={{ left: `${(mx * 0.5 + 0.5) * 100}%`, top: `${(0.5 - my * 0.5) * 100}%`, transform: 'translate(-50%,-50%)' }}>
        {edge ? (
          <div className="text-amber-300 text-xl drop-shadow" style={{ transform: `rotate(${-ang}deg)` }}>➤</div>
        ) : (
          <div className="relative">
            <div className="h-9 w-9 rounded-full border-2 border-amber-300/90 shadow-[0_0_12px_rgba(255,190,60,0.7)]" />
            <div className="absolute left-11 top-1/2 -translate-y-1/2 whitespace-nowrap font-mono text-[11px] text-amber-200 drop-shadow">
              {h.target.name}<br /><span className="text-amber-100/70">{fmtDist(h.target.dist)}</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  const near = !!h?.nearSurface;
  const pilot = mode === 'pilot';
  const eva = mode === 'eva';
  const walk = mode === 'walk';

  return (
    <div className="fixed inset-0 overflow-hidden bg-black text-white select-none" style={{ fontFamily: "'Segoe UI', system-ui, sans-serif", touchAction: 'none' }}>
      <div ref={mountRef} className="absolute inset-0" />

      {/* lapisan gestur */}
      <div className="absolute inset-0 z-[5]" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} onContextMenu={(e) => e.preventDefault()} />

      {started && h && (
        <>
          {/* efek layar */}
          {h.heat > 0.05 && (
            <div className="pointer-events-none absolute inset-0 z-[6] heat-fx" style={{ opacity: Math.min(1, h.heat * 1.2), background: 'radial-gradient(ellipse at 50% 55%, rgba(255,120,30,0) 30%, rgba(255,110,20,0.55) 75%, rgba(255,60,10,0.9) 100%)' }} />
          )}
          {h.glare > 0.02 && <div className="pointer-events-none absolute inset-0 z-[6]" style={{ opacity: h.glare * 0.75, background: 'radial-gradient(circle at 50% 45%, rgba(255,250,235,0.95), rgba(255,230,180,0.3) 55%, rgba(255,200,120,0) 85%)' }} />}
          {h.gasDepth > 0.01 && <div className="pointer-events-none absolute inset-0 z-[6] bg-black" style={{ opacity: Math.min(0.6, h.gasDepth * 25) }} />}
          {flash > 0 && <div className="pointer-events-none absolute inset-0 z-[7] bg-white" style={{ opacity: flash }} />}
          {eva && (
            <div className="pointer-events-none absolute inset-0 z-[6]" style={{ background: 'radial-gradient(ellipse 75% 70% at 50% 50%, rgba(0,0,0,0) 62%, rgba(4,8,14,0.55) 82%, rgba(2,4,8,0.95) 100%)', boxShadow: 'inset 0 0 60px rgba(120,200,255,0.18)' }} />
          )}
          {(pilot || walk) && <div className="pointer-events-none absolute inset-0 z-[6]" style={{ boxShadow: 'inset 0 0 120px rgba(0,0,0,0.55)' }} />}
          <div className="pointer-events-none absolute inset-0 z-[30] bg-black" style={{ opacity: h.fade }} />

          {markerEl}

          {/* bar atas */}
          <div className="absolute left-0 right-0 top-0 z-20 flex items-start justify-between px-3 pt-[max(10px,env(safe-area-inset-top))] pointer-events-none">
            <div className="font-mono leading-tight drop-shadow">
              <div className="text-[10px] tracking-[0.2em] text-cyan-300/70">{eva ? 'EVA' : walk ? 'KABIN' : mode === 'airlock' ? 'AIRLOCK' : 'KEMUDI'}</div>
              <div className="text-lg text-white">{fmtSpeed(h.speed)}</div>
              <div className="text-[11px] text-cyan-100/80">{h.alt > 0 ? fmtDist(h.alt) : '0 m'} · {h.nearest}</div>
              {eva && (
                <div className="mt-1 w-24">
                  <div className="text-[9px] tracking-widest text-sky-200/70">O₂ {Math.round(h.oxygen * 100)}%</div>
                  <div className="h-1.5 w-full overflow-hidden rounded bg-white/15"><div className={`h-full ${h.oxygen < 0.2 ? 'bg-red-400' : 'bg-sky-300'}`} style={{ width: `${h.oxygen * 100}%` }} /></div>
                  <div className="mt-1 text-[10px] text-white/50">g {h.gravity.toFixed(2)} m/s²</div>
                </div>
              )}
            </div>
            <button
              className="pointer-events-auto mt-1 max-w-[46%] truncate rounded-full border border-amber-300/50 bg-black/40 px-3 py-1.5 text-xs text-amber-100 backdrop-blur active:scale-95"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() => { eng().audio.open(); setShowMap(true); }}
            >
              {h.target ? `◎ ${h.target.name} · ${fmtDist(h.target.dist)}` : '◎ Pilih target'}
              {h.autopilot && <span className="ml-1 text-emerald-300">● AP</span>}
            </button>
            <div className="pointer-events-auto flex gap-2">
              <TapBtn onTap={() => { eng().audio.open(); setShowMap(true); }} className="h-10 w-10 text-lg">🗺</TapBtn>
              <TapBtn onTap={() => eng().toggleMute()} className="h-10 w-10 text-base">{h.muted ? '🔇' : '🔊'}</TapBtn>
              <TapBtn onTap={() => setShowHelp(true)} className="h-10 w-10 text-base">?</TapBtn>
            </div>
          </div>

          {/* toast & peringatan */}
          <div className="pointer-events-none absolute left-0 right-0 top-[88px] z-20 flex flex-col items-center gap-1.5 px-6">
            {h.warn && <div className="warn-pulse rounded-full border border-red-400/70 bg-red-900/60 px-4 py-1.5 font-mono text-xs text-red-100">⚠ {h.warn}</div>}
            {toasts.map((t) => (
              <div key={t.id} className={`toast-in rounded-2xl border px-4 py-2 text-center text-sm backdrop-blur ${t.kind === 'discover' ? 'border-amber-300/60 bg-amber-500/20 text-amber-100' : t.kind === 'warn' ? 'border-red-400/50 bg-red-900/40 text-red-100' : 'border-cyan-300/30 bg-black/50 text-cyan-50'}`}>{t.text}</div>
            ))}
          </div>

          {/* urutan airlock */}
          {h.seq && (
            <div className="pointer-events-none absolute inset-x-0 bottom-[28%] z-[25] flex flex-col items-center">
              <div className="rounded-xl border border-cyan-300/40 bg-black/60 px-5 py-3 font-mono text-sm text-cyan-100 backdrop-blur">
                <span className="mr-2 inline-block h-2 w-2 animate-pulse rounded-full bg-amber-400" />{h.seq}
              </div>
            </div>
          )}

          {/* throttle (pilot) */}
          {pilot && (
            <div className="pointer-events-none absolute bottom-[max(24px,env(safe-area-inset-bottom))] left-4 z-10 flex items-end gap-2">
              <div className="relative h-[34vh] w-3 overflow-hidden rounded-full border border-cyan-300/40 bg-black/40">
                <div className={`absolute bottom-0 w-full ${h.throttle > 0.85 ? 'bg-amber-400' : 'bg-cyan-300'}`} style={{ height: `${h.throttle * 100}%` }} />
              </div>
              <div className="pb-1 font-mono text-[10px] leading-tight text-cyan-100/80">
                DAYA<br /><span className="text-base text-white">{Math.round(h.throttle * 100)}%</span><br />
                <span className="text-white/40">geser ↑↓</span><br />
                <span className="text-white/40">batas {fmtSpeed(h.limit)}</span>
              </div>
            </div>
          )}

          {/* tombol kanan */}
          <div className="absolute bottom-[max(20px,env(safe-area-inset-bottom))] right-3 z-20 flex flex-col items-center gap-2.5">
            {pilot && (
              <>
                <div className="flex flex-col gap-2">
                  <TapBtn onTap={() => eng().toggleLook()} active={h.look} className="h-10 w-10 text-base">👁</TapBtn>
                  <TapBtn onTap={() => eng().toggleView()} active={h.view === 'chase'} className="h-10 w-10 text-base">🎥</TapBtn>
                  <TapBtn onTap={() => eng().standSit()} className="h-10 w-10 text-base">🧍</TapBtn>
                </div>
                {h.target && (
                  <TapBtn onTap={() => (h.autopilot ? eng().cancelAutopilot() : eng().engageAutopilot())} active={h.autopilot} className="h-14 w-14 flex-col text-[10px] font-mono leading-none"><span className="text-lg">⌖</span>AUTO</TapBtn>
                )}
                <HoldBtn onDown={() => eng().setBoost(true)} onUp={() => eng().setBoost(false)} active={h.boost} className="h-14 w-14 flex-col text-[10px] font-mono leading-none"><span className="text-lg">⚡</span>BOOST</HoldBtn>
                <HoldBtn onDown={() => eng().brake(true)} onUp={() => eng().brake(false)} className="h-14 w-14 flex-col text-[10px] font-mono leading-none border-red-400/60 text-red-200"><span className="text-lg">■</span>REM</HoldBtn>
              </>
            )}
            {walk && (
              <>
                {h.prompt?.action !== 'sit' && <TapBtn onTap={() => eng().standSit()} className="h-12 w-12 text-sm">🪑</TapBtn>}
              </>
            )}
            {eva && (
              <>
                <TapBtn onTap={() => eng().returnToShip()} className="h-12 w-12 flex-col text-[9px] font-mono leading-none"><span className="text-base">↩</span>TARIK</TapBtn>
                <TapBtn onTap={() => eng().jump()} className="h-12 w-12 flex-col text-[9px] font-mono leading-none"><span className="text-base">⤒</span>LOMPAT</TapBtn>
                <HoldBtn onDown={() => eng().setJet(false, true)} onUp={() => eng().setJet(false, false)} className="h-12 w-12 text-lg">▼</HoldBtn>
                <HoldBtn onDown={() => eng().setJet(true, false)} onUp={() => eng().setJet(false, false)} className="h-16 w-16 flex-col text-[9px] font-mono leading-none border-sky-300/70 text-sky-100"><span className="text-xl">▲</span>JETPACK</HoldBtn>
              </>
            )}
          </div>

          {/* tombol tengah bawah: roll & thruster vertikal */}
          {pilot && (
            <div className="absolute bottom-[max(20px,env(safe-area-inset-bottom))] left-1/2 z-20 flex -translate-x-1/2 gap-2">
              <HoldBtn onDown={() => eng().setRoll(-1)} onUp={() => eng().setRoll(0)} className="h-11 w-11 text-lg">⟲</HoldBtn>
              {near && (
                <>
                  <HoldBtn onDown={() => eng().setVert(-1)} onUp={() => eng().setVert(0)} className="h-11 w-11 text-base">▼</HoldBtn>
                  <HoldBtn onDown={() => eng().setVert(1)} onUp={() => eng().setVert(0)} className="h-11 w-11 text-base">▲</HoldBtn>
                </>
              )}
              <HoldBtn onDown={() => eng().setRoll(1)} onUp={() => eng().setRoll(0)} className="h-11 w-11 text-lg">⟳</HoldBtn>
            </div>
          )}

          {/* prompt kontekstual */}
          {h.prompt && (
            <div className="absolute inset-x-0 bottom-[22%] z-20 flex justify-center">
              <button
                className="prompt-glow rounded-full border border-amber-300/80 bg-amber-400/90 px-6 py-3 text-sm font-semibold text-black shadow-lg active:scale-95"
                onPointerDown={(e) => e.stopPropagation()}
                onClick={() => eng().interact()}
              >
                {h.prompt.action === 'flag' ? '⚑' : '▶'} {h.prompt.text}
              </button>
            </div>
          )}

          {/* stick virtual */}
          {(['L', 'R'] as const).map((z) => {
            const s = stick[z];
            if (!s) return null;
            return (
              <div key={z} className="pointer-events-none absolute z-10" style={{ left: s.cx - 40, top: s.cy - 40 }}>
                <div className="h-20 w-20 rounded-full border border-white/30 bg-white/5" />
                <div className="absolute h-9 w-9 rounded-full border border-cyan-200/70 bg-cyan-300/30" style={{ left: 22 + s.x * 0.5, top: 22 + s.y * 0.5 }} />
              </div>
            );
          })}

          {/* tips awal */}
          {tip && !showMap && (
            <div className="absolute inset-x-4 top-[150px] z-20 mx-auto max-w-sm rounded-2xl border border-cyan-300/30 bg-black/55 p-3 text-[12px] leading-snug text-cyan-50 backdrop-blur" onPointerDown={(e) => e.stopPropagation()}>
              <div className="mb-1 font-semibold text-amber-200">Selamat datang, Kapten.</div>
              <ul className="space-y-0.5 text-white/80">
                <li>↕ Geser kiri: <b>daya dorong</b> — kapal melambat otomatis dekat planet</li>
                <li>✥ Geser kanan: <b>kemudi</b> · 🗺 pilih target lalu <b>AUTO</b></li>
                <li>🧍 Berdiri → jalan ke <b>airlock</b> (belakang) → <b>EVA</b> &amp; jalan di permukaan</li>
              </ul>
              <button className="mt-2 text-amber-300" onClick={() => setTip(false)}>Mengerti</button>
            </div>
          )}

          {showMap && eng() && (
            <MapPanel
              engine={eng()}
              targetId={h.target?.id || null}
              counts={h.counts}
              onClose={() => setShowMap(false)}
              onAutopilot={() => eng().engageAutopilot()}
            />
          )}

          {showHelp && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-5" onPointerDown={(e) => e.stopPropagation()}>
              <div className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-3xl border border-cyan-300/30 bg-[#050d14] p-5 text-sm text-white/85">
                <div className="mb-2 text-lg font-semibold text-cyan-200">Panduan Penerbangan</div>
                <p className="mb-2 text-white/70">Terbang dari angkasa hingga mendarat — tanpa teleportasi. Permukaan planet terbentuk progresif saat Anda mendekat.</p>
                <ul className="space-y-1.5 text-[13px]">
                  <li><b className="text-amber-200">Daya:</b> geser vertikal di separuh kiri layar. Batas aman kecepatan menyesuaikan ketinggian.</li>
                  <li><b className="text-amber-200">Kemudi:</b> geser di separuh kanan. ⟲⟳ untuk roll. 👁 = pandang bebas, 🎥 = kamera luar.</li>
                  <li><b className="text-amber-200">Peta 🗺:</b> pilih target, ▶ Autopilot terbang menuju. Bangkitkan dunia generatif baru dari peta.</li>
                  <li><b className="text-amber-200">Mendarat:</b> turunkan daya dekat permukaan, gunakan ▲▼ untuk presisi. Kaki pendarat turun otomatis.</li>
                  <li><b className="text-amber-200">Berdiri 🧍:</b> jelajahi kokpit, kabin, meja holo, kamar tidur, dapur, lalu airlock di belakang kanan.</li>
                  <li><b className="text-amber-200">EVA:</b> stik kiri = jalan/jetpack, geser kanan = menoleh, JETPACK/▼ naik-turun, tancapkan bendera 🇮🇩.</li>
                  <li className="text-white/50">Desktop: WASD/panah, Q/E roll, Shift/Ctrl daya, X rem, B boost, Spasi naik, T berdiri/duduk, F aksi, G bendera, V kamera, M suara. Drag mouse untuk melihat.</li>
                </ul>
                <button className="mt-4 w-full rounded-xl bg-cyan-400 py-2.5 font-semibold text-black" onClick={() => setShowHelp(false)}>Tutup</button>
              </div>
            </div>
          )}
        </>
      )}

      {/* layar pemuatan / awal */}
      {!started && (
        <div className="absolute inset-0 z-[60] flex flex-col items-center justify-end bg-gradient-to-b from-black/70 via-black/30 to-black/90 px-6 pb-[max(36px,env(safe-area-inset-bottom))] text-center">
          <div className="mb-auto mt-[14vh]">
            <div className="font-mono text-[11px] tracking-[0.5em] text-cyan-300/80">EKSPEDISI ANTARIKSA</div>
            <h1 className="mt-2 bg-gradient-to-b from-white to-cyan-300 bg-clip-text text-5xl font-black tracking-tight text-transparent">NUSANTARA</h1>
            <div className="mt-1 text-sm text-white/70">Jelajahi tata surya · mendarat di dunia generatif</div>
          </div>
          {!ready ? (
            <div className="w-full max-w-xs">
              <div className="mb-2 font-mono text-xs text-cyan-200/80">{progress.label}…</div>
              <div className="h-1.5 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-amber-300 transition-all" style={{ width: `${progress.p * 100}%` }} /></div>
            </div>
          ) : (
            <div className="w-full max-w-xs">
              <button onClick={start} className="w-full rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 py-4 text-lg font-bold text-black shadow-[0_0_40px_rgba(255,160,40,0.45)] active:scale-95">MULAI MISI</button>
              <div className="mt-3 text-[11px] text-white/50">Disarankan: layar penuh, suara aktif, mode lanskap atau potret</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
